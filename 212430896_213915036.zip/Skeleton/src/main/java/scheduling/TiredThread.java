package scheduling;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

public class TiredThread extends Thread implements Comparable<TiredThread> {

    private static final Runnable POISON_PILL = () -> {}; // Special task to signal shutdown

    private final int id; // Worker index assigned by the executor
    private final double fatigueFactor; // Multiplier for fatigue calculation

    private final AtomicBoolean alive = new AtomicBoolean(true); // Indicates if the worker should keep running

    // Single-slot handoff queue; executor will put tasks here
    private final BlockingQueue<Runnable> handoff = new ArrayBlockingQueue<>(1);

    private final AtomicBoolean busy = new AtomicBoolean(false); // Indicates if the worker is currently executing a task

    private final AtomicLong timeUsed = new AtomicLong(0); // Total time spent executing tasks
    private final AtomicLong timeIdle = new AtomicLong(0); // Total time spent idle
    private final AtomicLong idleStartTime = new AtomicLong(0); // Timestamp when the worker became idle

    public TiredThread(int id, double fatigueFactor) {
        this.id = id;
        this.fatigueFactor = fatigueFactor;
        this.idleStartTime.set(System.nanoTime());
        setName(String.format("FF=%.2f", fatigueFactor));
    }

    public int getWorkerId() {
        return id;
    }

    public double getFatigue() {
        return fatigueFactor * timeUsed.get();
    }

    public boolean isBusy() {
        return busy.get();
    }

    public long getTimeUsed() {
        return timeUsed.get();
    }

    public long getTimeIdle() {
        return timeIdle.get();
    }

    /**
     * Assign a task to this worker.
     * This method is non-blocking: if the worker is not ready to accept a task,
     * it throws IllegalStateException.
     */
    public void newTask(Runnable task) {
       if(!handoff.offer(task)){
            throw new IllegalStateException("Worker is not ready to accept a new task");
       }
    }

    /**
     * Request this worker to stop after finishing current task.
     * Inserts a poison pill so the worker wakes up and exits.
     */
    public void shutdown() {
        try {
            // insert poison pill to wake up the thread if it's waiting
           handoff.put(POISON_PILL);
       } catch (InterruptedException e) {
            // interrupt current thread if unable to insert poison pill
           Thread.currentThread().interrupt();
       }
    }

    @Override
    public void run() {
       while(alive.get()){
            try {
                Runnable task = handoff.take();
                
                //Calculate long delta of idle time and update time idle
                long idleDuration = System.nanoTime() - idleStartTime.get();
                timeIdle.addAndGet(idleDuration);

                // Check if shutdown
                if(task == POISON_PILL){
                    alive.set(false);
                    this.timeIdle.set(this.timeIdle.get()); // update idle time before exit
                    break;
                }

                // Execute task and measure time used
                busy.set(true);
                try {
                    task.run(); // Execute the task
                } catch (Exception e) {
                    e.printStackTrace();
                }
                busy.set(false);

            } catch (InterruptedException e) {
                alive.set(false);
                // interrupt current thread if unable to take task
                Thread.currentThread().interrupt();
            }
       }
    }

    @Override
    public int compareTo(TiredThread o) {
        if(this.getFatigue() > o.getFatigue())
            return 1;
        else if (this.getFatigue() < o.getFatigue())
            return -1;
        return 0;
    }

    //Helping Method: Allows external updates to execution time
    /**
     * Updates the total time used by this worker.
     * This is called by the Executor immediately after a task finishes,
     * ensuring the fatigue score is up-to-date before re-queueing.
     */
    public void addTime(long duration) {
        this.timeUsed.addAndGet(duration);
        // Reset the idle start time because the worker just finished working
        this.idleStartTime.set(System.nanoTime());
    }
}